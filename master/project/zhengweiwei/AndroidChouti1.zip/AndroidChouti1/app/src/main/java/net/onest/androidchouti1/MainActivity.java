package net.onest.androidchouti1;

import android.app.Activity;
import android.os.Bundle;

import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity extends Activity
{
    private DrawerLayout mDrawerLayout = null;
    private TextView tvIfVip;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //获取用户信息，如果是会员，设置
        tvIfVip=findViewById(R.id.tv_ifVip);
        if(1==1){//判断用户是否是会员
            tvIfVip.setText("您已成为会员");
        }



        mDrawerLayout = findViewById(R.id.drawer_layout);

        Button button = (Button) findViewById(R.id.btn);
        button.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v)
            {
                // 按钮按下，将抽屉打开
                mDrawerLayout.openDrawer(Gravity.LEFT);
            }
        });
    }

}
