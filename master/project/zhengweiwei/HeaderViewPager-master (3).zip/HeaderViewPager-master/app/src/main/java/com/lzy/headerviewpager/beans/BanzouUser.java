package com.lzy.headerviewpager.beans;

public class BanzouUser {
	private String name;
	private String banzou;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBanzou() {
		return banzou;
	}
	public void setBanzou(String banzou) {
		this.banzou = banzou;
	}
	
}
