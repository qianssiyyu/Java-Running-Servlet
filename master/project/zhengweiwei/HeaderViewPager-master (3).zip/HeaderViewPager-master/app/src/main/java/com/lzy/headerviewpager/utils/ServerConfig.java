package com.lzy.headerviewpager.utils;

public class ServerConfig {
    public final static String SERVER_ADDR = "http://10.7.89.111:8080";
    public final static String NET_HOME = "RapstarService";
    public final static String user_name="user1";
}
