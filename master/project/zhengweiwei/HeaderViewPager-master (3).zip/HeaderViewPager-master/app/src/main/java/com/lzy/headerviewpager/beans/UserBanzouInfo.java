package com.lzy.headerviewpager.beans;

import java.util.List;

public class UserBanzouInfo {
	private List<BanzouUser> users;

	public List<BanzouUser> getUsers() {
		return users;
	}

	public void setUsers(List<BanzouUser> users) {
		this.users = users;
	}

	@Override
	public String toString() {
		return "UserBanzouInfo [users=" + users + "]";
	}

	
}

