package com.lzy.headerviewpager;

import android.app.DownloadManager;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.lzy.headerviewpager.beans.BaseUser;
import com.lzy.headerviewpager.fragment.GridViewFragment;
import com.lzy.headerviewpager.fragment.ListViewFragment;
import com.lzy.headerviewpager.fragment.RecyclerViewFragment;
import com.lzy.headerviewpager.fragment.ScrollViewFragment;
import com.lzy.headerviewpager.fragment.WebViewFragment;
import com.lzy.headerviewpager.fragment.base.HeaderViewPagerFragment;
import com.lzy.headerviewpager.utils.CircleImageView;
import com.lzy.headerviewpager.utils.ServerConfig;
import com.lzy.widget.HeaderViewPager;
import com.lzy.widget.tab.PagerSlidingTabStrip;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static java.lang.Integer.parseInt;

public class MainActivity extends BaseActivity {

    public List<HeaderViewPagerFragment> fragments;
    private HeaderViewPager scrollableLayout;
    private CircleImageView iv_header;
    private TextView tv_user_name;
    private TextView tv_guanzhu;
    private TextView tv_fensi;
    private ImageView iv_pen;
    private Handler myHandler;
    private OkHttpClient okHttpClient;
    //private Gson gson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
        //内容的fragment
        fragments = new ArrayList<>();
        fragments.add(ScrollViewFragment.newInstance());
        fragments.add(ListViewFragment.newInstance());
        fragments.add(GridViewFragment.newInstance());
        fragments.add(RecyclerViewFragment.newInstance());
        fragments.add(WebViewFragment.newInstance());

        scrollableLayout = (HeaderViewPager) findViewById(R.id.scrollableLayout);

        //tab标签和内容viewpager
        PagerSlidingTabStrip tabs = (PagerSlidingTabStrip) findViewById(R.id.tabs);
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewPager);
        viewPager.setAdapter(new ContentAdapter(getSupportFragmentManager()));
        tabs.setViewPager(viewPager);
        scrollableLayout.setCurrentScrollableContainer(fragments.get(0));
        viewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                scrollableLayout.setCurrentScrollableContainer(fragments.get(position));
            }
        });

        viewPager.setCurrentItem(0);
        //上传用户名，得到用户基本信息
      //  simpStringParamPostRequest2(ServerConfig.user_name);
        myHandler=new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                switch (msg.what) {
                    case 1://下载数据完成，将下载好的数据显示在页面上
                        //1. 获取下载完成的数据
                        //设置头像，用户名，关注数，粉丝数
                        BaseUser user=(BaseUser) msg.obj;
                        iv_header.setImageBitmap(BitmapFactory.decodeFile(user.getPhotopath()));
                        tv_user_name.setText(user.getPhone());
                        tv_fensi.setText(user.getFollowers());
                        tv_guanzhu.setText(user.getStars());
                        break;
                }
            }
        };
    }

    private void findViews() {
        iv_header=(CircleImageView)findViewById(R.id.iv_header);
        tv_user_name=(TextView) findViewById(R.id.tv_user_name);
        tv_guanzhu=(TextView)findViewById(R.id.tv_guanzhu);
        tv_fensi=(TextView)findViewById(R.id.tv_fensi);
        iv_pen=(ImageView)findViewById(R.id.iv_pen);
    }


    /**
     * 内容页的适配器
     */
    private class ContentAdapter extends FragmentPagerAdapter {

        public ContentAdapter(FragmentManager fm) {
            super(fm);
        }

        public String[] titles = new String[]{"伴奏单", "歌单", "GridView消息", "RecyclerView动态", "网页搜索"};

        @Override
        public CharSequence getPageTitle(int position) {
            return titles[position];
        }

        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }
    }
    private void simpStringParamPostRequest2(String str) {
        //2 创建Request对象
        //1) 使用RequestBody封装请求数据
        //获取待传输数据对应的MIME类型
        Log.e("oooooooooooo",str);
        MediaType type = MediaType.parse("text/plain");
        //创建RequestBody对象
        RequestBody reqBody = RequestBody.create(
                str,
                type
        );
        //2) 创建请求对象
        Request request = new Request.Builder()
                .url("http://10.7.89.111:8080/RapstarServer/user/getUserMsg")
                .post(reqBody)
                .build();
        //Log.i("lallll",ServerConfig.SERVER_HOME + "user/login");
        //3. 创建CALL对象
        Call call = okHttpClient.newCall(request);
        //4. 提交请求并获取响应
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.i("lww", "请求失败");
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String result = response.body().string();
                Log.i("user", "onResponse: "+result);

//                Message msg = handler.obtainMessage();
//                msg.what = 1;
//                msg.obj = result;
//                handler.sendMessage(msg);
            }
        });
    }

}
