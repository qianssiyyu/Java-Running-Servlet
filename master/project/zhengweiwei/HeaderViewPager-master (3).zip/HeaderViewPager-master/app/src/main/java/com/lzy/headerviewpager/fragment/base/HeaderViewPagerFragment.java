package com.lzy.headerviewpager.fragment.base;

import androidx.fragment.app.Fragment;

import com.lzy.widget.HeaderScrollHelper;

/**
 * ================================================
 * 作    者：廖子尧
 * 版    本：1.0
 * 创建日期：2016/2/22
 * 描    述：
 * 修订历史：
 * ================================================
 */
public abstract class HeaderViewPagerFragment extends Fragment implements HeaderScrollHelper.ScrollableContainer {}
